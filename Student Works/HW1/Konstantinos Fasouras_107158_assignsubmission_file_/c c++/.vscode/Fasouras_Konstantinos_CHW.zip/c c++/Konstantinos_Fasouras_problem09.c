#include<stdio.h>
int main(){
    //declaration
    int dDay;
    //information
    printf("This will be your favorite calendar! Which day of the week will ti start?");
    printf("Press:  0 for Sun, 1 for Mon, 2 for Tue, 3 for Wed, 4 for Thu, 5 for Fri, 6 for Sat");
    scanf("%d", &dDay);
    //switch
    switch (dDay){
        ///////
    
    }//endswitch
    return 0;
}

i tried this way but figured that will never work.  I have no idead how this will work.
i am not at that level yet.