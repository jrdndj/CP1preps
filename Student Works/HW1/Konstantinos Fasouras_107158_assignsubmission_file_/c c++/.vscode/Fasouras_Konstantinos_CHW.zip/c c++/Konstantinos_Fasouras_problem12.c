it is a big program and i was running out of time so i will descirbe it.
we know that :
I=1
V=5
X=10
L=50
C=100
D=500
M=1000
so we will play with if and for statements all the way to fighure each time if it is 1000 in the start
then if it bigger than 500, to check many cases, under 500, to check many cases
then we go around 100 for the same thing as 500. but possibly this will happen for every hundred: 100,200,300, etc
finally we will go under 100, there the things will be easier but will do the same procces

sorry for not writing the program but the time was too little for all of the 16 programms.