/*Anja Popovic, 89201065*/

#include<stdio.h>

//function declaration 
//Using some N just as a parametar(no meaning at all)  
 int SquOfFactor(int N);
 int Factor(int N);

int main() {

	//declaring variables
	int Tests;
	int NumWeEnter[200000];

	//Getting number that will represent the size of array
	printf("\nEnter number of tests!\n");
	scanf("%d", &Tests);

	if (Tests >= 1 && Tests <= 200000) {
		//adding elements in the array
		printf("\nEnter numbers \n");
		for (int i = 0; i < Tests; i++) {
			scanf("%d", &NumWeEnter[i]);
		}//endfor
		//finding the multiples 
		/* i goes through array of size Tests and pick a number
		In next loop, j will go from 1 till the SquOfFactor(NumWeEnter[i]) 
		Then in if statement we see if factorial of that j is a multiple of SquOfFactor(NumWeEnter[i])
		If yes, then we print j*/
		for (int i = 0; i < Tests; i++) {
			for (int j = 1; j <= SquOfFactor(NumWeEnter[i]); j++) {
				if (Factor(j) % SquOfFactor(NumWeEnter[i]) == 0) {
					printf("%d\n", j);
					break;
					
				}//endif
			

			}//endfor
		}//endfor

	}//endif
	return 0;
}//endmain

//We calculate Square of N!(Factorials of numbers that we enter or NumWeEnter)
 int SquOfFactor(int N) {

	int Fac = 1;
	int SquOfFactor = 1;

	//We go through first loop and make factorial of a number(it will be number that we have entered)
	if (N >= 1 || N!=0) {
		for (int i = 1; i <= N; i++) {
			Fac = Fac * i;
		}//endfor

		//Here we square the factorial of number 
		SquOfFactor = Fac * Fac;

	}//endif
	//We return the square of factorial of number
	return SquOfFactor;
}//endSquOfFactor

 //Calculate the Factorials of numbers that go till SquOfFactor
 int Factor(int N) {
	double Fac = 1;
	for (int i = 1; i <= N; i++) {
		Fac = Fac * i;
	}//endfor
	return Fac;
 }//endFactor
 
	 
 /*DISCLAIMER:
 There is a problem when I pass number bigger than 5, when i print Factor of, lets say 5 and 6 it is the same number
 I have had a trouble finding the problem, could be the int and double part(cause it is not really clear to me), but not sure*/
 /*Also, I tried using more arrays, but I got error everytime, don't know why*/