//
//  main.c
//  HW_2
//

#include <stdio.h>
#include <math.h>

typedef enum {true, false} bool;

long factorial(int n)
{
  if (n == 0)
    return 1;
  else
    return (n*factorial(n-1));
}

int getNumberByFactorial(int factorialOfNumber){
    
    return -1;
}


int main(int argc, const char * argv[]) {
    
    int countOfNumbers = 0;
    int currentNumber = 0;
    long factorialOfK = 0;
    
    scanf("%d", &countOfNumbers);

    for (int i=0; i<countOfNumbers; i++) {
        scanf("%d", &currentNumber);
        factorialOfK = pow(factorial(currentNumber),2);
    }
    
    
    return 0;
}
