
#include<stdio.h>

int Factorial(int);

void main() {
	int dTest, dN[10], dCounter=2;
	float fN2[10], fResult=0.5;
	printf("Enter a number of test cases you would like to perform.\n");
	scanf_s("%d", &dTest);
	//It asks for how many test cass you want to do but it needs to be between 1 and 10
	if (dTest >= 1 && dTest <= 10) {
		//Collecting the inputs
		for (int i = 0; i < dTest; i++) {
			printf("Enter %d. number: ", i + 1);
			scanf_s("%d", &dN[i]);
			if (dN[i] < 1 || dN[i]>10) {
				printf("Please enter a number between 1 and 10!\n");
				scanf_s("%d", &dN[i]);
			}
			//Changing inputs to factorials with the method we created
			fN2[i] = Factorial(dN[i]);
			fN2[i] = fN2[i] * fN2[i];
		}
		//Here i search for the k 
		//the program doesnt work entirely for some numbers it s giving the wrong answer
		for (int i = 1; i <= dTest; i++) {
			while (fResult - (int)fResult != 0) {
				dCounter++;
				fResult = Factorial(dCounter) / fN2[i - 1];

			}
			printf("%d ", dCounter);
			dCounter = 2;
			fResult = 0.5;
		}
	}
	else {
		printf("Please enter a number between 1 and 10!\n");
	}

}
//Method for creating factorials
int Factorial(int dNum) {
	int dResult = 1;
	for (int i = 0; i < dNum; i++) {
		dResult *= i + 1;
	}
	return dResult;
}

