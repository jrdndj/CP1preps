#include<stdio.h>
#include <math.h>

int main() {

    //declaring variables
    int dKnum, dTest, dNum, dCtr1, dCtr2;
    double fNFact, fKFact, fNFactSquare, fMod;

    //input number of test from user
    printf("Please, type how many numbers you want to test numbers?\n");
    scanf("%d", &dTest); //it is like number of elements in array

    //checking t
    if(dTest>+1 && dTest <= 200000) { //if condition
        for(dCtr1 = 1; dCtr1 <= dTest; dCtr1++) {
            printf("Please, enter positive integer: "); //ask user for integers
            scanf("%d", &dNum); //scan input

            if(dNum >= 1 && dNum <= 200000) { //2nd if
                fKFact = 1;
                fNFact = 1;

                for(dCtr2 = 1; dCtr2 <= dNum; dCtr2++) { //for loop
                    fNFact*=dCtr2;
                }
                fNFactSquare = fNFact * fNFact;

                for( dKnum = 1; ; dKnum++) { //2nd for loop
                    fKFact = fKFact* dKnum;

                    fMod = fmod(fKFact,fNFactSquare);
                    if(fMod == 0) { //3rd if
                        printf("\n %d", &dKnum);
                    } //end3rdif
                } //end2ndfor
            }//end 2ndif
        }//endfor
    }



return 0;
}


