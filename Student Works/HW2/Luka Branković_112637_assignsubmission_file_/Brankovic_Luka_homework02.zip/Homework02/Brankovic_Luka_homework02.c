//This code was written by Luka Brankovic, 14.1.2021.
//I couldn't put the top boundary at 200000 because my program would constantly crash :(

#include <stdio.h> 
#include <stdlib.h> 


  //This function finds on what power is factor dP for inputed number dN!
  //for example dN = 4 => 4! = 4 * 3 * 2 = 2^2 * 3 * 2 = 3 * 2^3
  //Which means that largestPower(4,2) would return 3

int largestPower(int dN, int dP) // 
{
    int dX = 0;

    while (dN)
    {
        dN /= dP;
        dX += dN;
    }
    return dX;
}



  //This returns "true" if the number is a prime number

int isPrime(int dN)
{
    int flag = 1;
    for (int i = 2; i <= dN / 2; i++)
    {
        if (dN % i == 0) {
            flag = 0;
            break;
        }
    }

    return flag;
}

int main()
{
    int dN;
    int dT;
    int dfactorsCount;

    printf("Input how many times you would like to perform the operation: ");
    scanf_s("%d", &dT);

    for (int u = 0; u < dT; u++)
    {
        printf("Input number N: ");
        scanf_s("%d", &dN);

        // The length of the array in which we store factors
        dfactorsCount = dN * 2;

        int dAfactors[1000];
        int dAnewFactors[1000];

        for (int i = 0; i < dfactorsCount; i++)
        {
            dAfactors[i] = 0;
            dAnewFactors[i] = 0;
        }

        //For dN we fill in the powers of their factors and multiply each by 2 (because it is the same as squaring n!)
        for (int i = 2; i <= dN; i++)
        {
            if (isPrime(i))
                dAfactors[i] = largestPower(dN, i) * 2;
        }

        // For every number from dN+1 until the end(dfactorsCount) we calculate the powers of the factors
        // We set the int dFlag to be true (1) which will determine wheather we've found the result (K)
        // The second for loop determines, for every second value of i, the array which contains the power of factors and then it compares it with the array we formed for dN in the beginning
        // If there is a number in the array dAfactors which is larger than the number at the same position in dAnewFactors, that tells the compiler that number "i" isn't the number we were looking for
        // After than we set the dFlag to false (0) so we could tell the program that the number is not found
        // When we find the number "i", dFlag won't change (remains true), which means exiting the for loop
        // And then, when we leave the loop, the current number "i" will be the resulting K (i = K)
        int i, j;
        for (i = dN + 1; i < dfactorsCount; i++)
        {
            int dFlag = 1;
            for (j = 2; j <= i; ++j)
            {
                if (isPrime(j))
                    dAnewFactors[j] = largestPower(i, j);
            }

            int p = 0;
            while (dFlag && p < i)
            {
                if (dAfactors[p] > dAnewFactors[p])
                    dFlag = 0;

                p++;
            }

            if (dFlag) break;
        }

        printf("K = %d\n", i);
    }

    return 0;
}
